
// Simple static storefront (simulated checkout). Loads products from products.json
async function loadProducts(){
  const res = await fetch('products.json');
  const products = await res.json();
  const el = document.getElementById('products');
  el.innerHTML = '';
  products.forEach(p => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <h4>${p.name}</h4>
      <p>${p.description}</p>
      <div class="price">€${p.price.toFixed(2)}</div>
      <div class="actions">
        <button class="btn buy-btn" data-id="${p.id}">Koop</button>
        <a class="btn" href="${p.filename}" download>Preview</a>
      </div>
    `;
    el.appendChild(card);
  });
  document.querySelectorAll('.buy-btn').forEach(b=>b.addEventListener('click', addToCart));
}

let cart = [];
function addToCart(e){
  const id = e.currentTarget.dataset.id;
  fetch('products.json').then(r=>r.json()).then(products=>{
    const prod = products.find(x=>x.id===id);
    cart.push(prod);
    showCart();
  });
}

function showCart(){
  const cartEl = document.getElementById('cart');
  const items = document.getElementById('cart-items');
  items.innerHTML = cart.map((c,i)=>`<div>${c.name} - €${c.price.toFixed(2)}</div>`).join('');
  cartEl.classList.remove('hidden');
}

document.getElementById('checkout').addEventListener('click', ()=>{
  alert('Dit is een betalings-simulatie. Integreer Stripe of PayPal voor echte betalingen.');
});

// init
loadProducts();
