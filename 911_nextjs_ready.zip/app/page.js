
export default function Home() {
  return (
    <main>
      <h1>911 Shop</h1>
      <p>Next.js conversion working.</p>
    </main>
  );
}
