export default function Home() {
  return (
    <main style={{padding:20}}>
      <h1>Mod Shop</h1>
      <ul>
        <li>Fortnite Modz</li>
        <li>GTA Mod Menu</li>
        <li>Nitro Boosts</li>
        <li>Fivem Modz</li>
        <li>Roblox Executor</li>
      </ul>
    </main>
  );
}
